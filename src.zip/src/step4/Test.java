package step4;

/**
 * Created by Pluck on 1/26/2016.
 */


public class Test {

    public int add(int a, int b){
        return a + b;
    }

    public int multiply(int a, int b){
        return a * b;
    }
}