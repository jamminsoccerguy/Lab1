package step5;

/**
 * Created by Pluck on 1/26/2016.
 */


public class WhileExample {

    public static void main (String[] args){

        int count = 1;
        while(count < 11) {
            System.out.println("Count is: " + count);
            count++;
        }
    }
}